﻿namespace Nml.Improve.Me.Dependencies
{
	public class Person
	{
		public string FirstName { get; set; }
		public string Surname { get; set; }
	}
}