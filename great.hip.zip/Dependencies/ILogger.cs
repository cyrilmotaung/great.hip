﻿namespace Nml.Improve.Me.Dependencies
{
	public interface ILogger<T>
	{
		void LogWarning(string message);
	}
}