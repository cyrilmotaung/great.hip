﻿namespace Nml.Improve.Me.Dependencies
{
	public enum PageNumbers
	{
		Numeric
	}
}