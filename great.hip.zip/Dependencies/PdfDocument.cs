﻿namespace Nml.Improve.Me.Dependencies
{
	public class PdfDocument
	{
		public byte[] ToBytes()
		{
			return new byte[0];
		}
	}
}