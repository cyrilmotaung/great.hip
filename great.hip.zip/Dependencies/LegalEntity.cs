﻿namespace Nml.Improve.Me.Dependencies
{
	public class LegalEntity
	{
	}
}